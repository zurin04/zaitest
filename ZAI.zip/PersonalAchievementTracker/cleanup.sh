#!/bin/bash

# Cleanup script for Crypto Airdrop Platform
# Removes old installation files and fixes common issues

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

PROJECT_NAME="crypto-airdrop"
PROJECT_DIR="/var/www/crypto-airdrop"

echo -e "${BLUE}🧹 Cleaning up old installation files...${NC}"

# Stop existing PM2 processes
echo "Stopping PM2 processes..."
pm2 delete $PROJECT_NAME 2>/dev/null || true
pm2 delete all 2>/dev/null || true

# Remove problematic files
echo "Removing old configuration files..."
rm -f $PROJECT_DIR/ecosystem.config.js
rm -f $PROJECT_DIR/ecosystem.config.mjs
rm -f $PROJECT_DIR/.env
rm -rf $PROJECT_DIR/node_modules/.cache
rm -rf $PROJECT_DIR/dist

# Clear PM2 logs
pm2 flush

# Reset PM2 configuration
pm2 kill
pm2 resurrect

echo -e "${GREEN}✓ Cleanup completed${NC}"
echo ""
echo "Now run the installation script:"
echo "chmod +x install.sh && ./install.sh"