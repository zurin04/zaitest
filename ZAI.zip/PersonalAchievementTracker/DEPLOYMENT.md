# Production Deployment Guide

## Quick Fix for Your Current Issue

Your PM2 process is failing because it's trying to run `/var/www/crypto-airdrop/dist/index.js` which doesn't exist. Here's how to fix it:

### 1. Navigate to your project directory
```bash
cd /var/www/crypto-airdrop
```

### 2. Install dependencies (if not already done)
```bash
npm install
```

### 3. Build the project
```bash
npm run build
```

### 4. Update your PM2 configuration
Create or update your PM2 ecosystem file:

```javascript
// ecosystem.config.js
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'dist/index.js',
    cwd: '/var/www/crypto-airdrop',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      DATABASE_URL: 'your_database_url_here'
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/pm2/crypto-airdrop-error.log',
    out_file: '/var/log/pm2/crypto-airdrop-out.log',
    log_file: '/var/log/pm2/crypto-airdrop.log'
  }]
};
```

### 5. Start with PM2
```bash
pm2 delete crypto-airdrop  # Remove existing process
pm2 start ecosystem.config.js
pm2 save
```

### 6. Update Nginx Configuration
Ensure your nginx config points to the correct port:

```nginx
server {
    listen 80;
    server_name zaihash.xyz www.zaihash.xyz;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket support
    location /ws {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 7. Restart services
```bash
sudo nginx -t  # Test nginx config
sudo systemctl reload nginx
pm2 restart crypto-airdrop
```

## Environment Variables Required

Make sure these environment variables are set in your production environment:

```bash
DATABASE_URL=your_postgresql_connection_string
NODE_ENV=production
PORT=3000
SESSION_SECRET=your_random_session_secret_here
```

## Database Setup

Run these commands to set up your database:

```bash
npm run db:push
npm run db:seed
```

## Troubleshooting

1. **Check PM2 logs**: `pm2 logs crypto-airdrop`
2. **Check if build exists**: `ls -la dist/`
3. **Test local connection**: `curl http://localhost:3000`
4. **Check nginx logs**: `sudo tail -f /var/log/nginx/error.log`

The key issue was that your PM2 process was trying to run a compiled JavaScript file that didn't exist because the project hadn't been built for production.