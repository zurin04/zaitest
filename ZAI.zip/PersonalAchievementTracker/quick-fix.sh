#!/bin/bash

# Quick fix for current deployment issue
# Run this on your production server to fix the DATABASE_URL error

PROJECT_NAME="crypto-airdrop"
PROJECT_DIR="/var/www/crypto-airdrop"

echo "🔧 Quick fix for DATABASE_URL issue..."

# Navigate to project directory
cd $PROJECT_DIR

# Stop current process
pm2 delete $PROJECT_NAME 2>/dev/null || true

# Create environment file with your database credentials
# REPLACE THESE VALUES WITH YOUR ACTUAL DATABASE CREDENTIALS
cat > .env.production << EOF
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://crypto_user:crypto_pass_2024@localhost:5432/crypto_airdrop
SESSION_SECRET=$(openssl rand -base64 32)
PGHOST=localhost
PGPORT=5432
PGUSER=crypto_user
PGPASSWORD=crypto_pass_2024
PGDATABASE=crypto_airdrop
EOF

# Start application with environment file
pm2 start dist/index.js --name $PROJECT_NAME --env production --env-file .env.production
pm2 save

echo "✓ Application restarted with proper environment variables"
echo "Check status: pm2 logs $PROJECT_NAME"