# Crypto Airdrop Platform - Easy Setup

## Quick Installation (Recommended)

**Just run one command on your VPS:**

```bash
# Upload your files to VPS, then run:
chmod +x auto-install.sh
sudo ./auto-install.sh
```

That's it! Your crypto airdrop platform will be running automatically.

## What the Auto-Install Does

- Installs Node.js, PostgreSQL, Nginx, PM2
- Sets up database and creates all tables
- Configures web server
- Starts your application
- Shows you the website URL and login details

## After Installation

**Your site will be available at:**
- `http://your-server-ip`

**Login with:**
- Admin: `admin` / `admin123`
- Demo: `demo` / `demo123`

## Manual Installation

If you prefer to install step-by-step manually, see `SIMPLE_MANUAL_GUIDE.md`

## Troubleshooting

**Check if everything is running:**
```bash
pm2 status                 # Check app
systemctl status nginx     # Check web server
systemctl status postgresql # Check database
```

**View logs:**
```bash
pm2 logs crypto-airdrop    # App logs
```

**Restart if needed:**
```bash
pm2 restart crypto-airdrop # Restart app
systemctl restart nginx    # Restart web server
```

## Features

- User registration and authentication
- Crypto airdrop listings
- Real-time crypto prices
- Admin dashboard
- Live chat
- Creator applications
- Mobile responsive design