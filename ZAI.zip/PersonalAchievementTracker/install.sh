#!/bin/bash

# Crypto Airdrop Platform - Automated Installation Script
# This script sets up the complete production environment

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="crypto-airdrop"
PROJECT_DIR="/var/www/crypto-airdrop"
DOMAIN="zaihash.xyz"
APP_PORT=3000

echo -e "${BLUE}🚀 Starting Crypto Airdrop Platform Installation${NC}"
echo "================================================="

# Function to print status
print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root"
   exit 1
fi

# Step 1: System Updates and Dependencies
echo -e "${BLUE}📦 Installing system dependencies...${NC}"
apt update && apt upgrade -y
apt install -y curl wget git nginx postgresql postgresql-contrib

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PM2 globally
npm install -g pm2

print_status "System dependencies installed"

# Step 2: PostgreSQL Setup
echo -e "${BLUE}🗃️ Setting up PostgreSQL...${NC}"
systemctl start postgresql
systemctl enable postgresql

# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE crypto_airdrop;
CREATE USER crypto_user WITH ENCRYPTED PASSWORD 'crypto_pass_2024';
GRANT ALL PRIVILEGES ON DATABASE crypto_airdrop TO crypto_user;
ALTER USER crypto_user CREATEDB;
\q
EOF

print_status "PostgreSQL database created"

# Step 3: Application Setup
echo -e "${BLUE}📁 Setting up application...${NC}"

# Stop and remove any existing PM2 processes
pm2 delete $PROJECT_NAME 2>/dev/null || true

# Create project directory
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

# If project exists, backup and clean
if [ -d ".git" ]; then
    print_warning "Existing project found, creating backup..."
    cp -r . ../crypto-airdrop-backup-$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
fi

# Clone or update project (replace with your repository)
if [ ! -d ".git" ]; then
    # Initialize as git repo if needed
    git init
    print_status "Project directory prepared"
else
    git pull origin main 2>/dev/null || true
fi

# Install dependencies
print_status "Installing Node.js dependencies..."
npm install

# Step 4: Environment Configuration
echo -e "${BLUE}⚙️ Creating environment configuration...${NC}"

# Create production environment file
cat > .env.production << EOF
NODE_ENV=production
PORT=$APP_PORT
DATABASE_URL=postgresql://crypto_user:crypto_pass_2024@localhost:5432/crypto_airdrop
SESSION_SECRET=$(openssl rand -base64 32)
PGHOST=localhost
PGPORT=5432
PGUSER=crypto_user
PGPASSWORD=crypto_pass_2024
PGDATABASE=crypto_airdrop
EOF

# Export environment variables for current session
export $(cat .env.production | xargs)

print_status "Environment configured"

# Step 5: Build Application
echo -e "${BLUE}🔨 Building application...${NC}"
npm run build

# Verify build completed
if [ ! -f "dist/index.js" ]; then
    print_error "Build failed - dist/index.js not found"
    exit 1
fi

print_status "Application built successfully"

# Step 6: Database Schema and Seeding
echo -e "${BLUE}🗃️ Setting up database schema...${NC}"
npm run db:push
npm run db:seed

print_status "Database schema and seed data created"

# Step 7: PM2 Configuration
echo -e "${BLUE}🔄 Configuring PM2...${NC}"

# Create PM2 ecosystem file
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: '$PROJECT_NAME',
    script: 'dist/index.js',
    cwd: '$PROJECT_DIR',
    env: {
      NODE_ENV: 'production',
      PORT: $APP_PORT,
      DATABASE_URL: 'postgresql://crypto_user:crypto_pass_2024@localhost:5432/crypto_airdrop',
      SESSION_SECRET: '$(openssl rand -base64 32)'
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/pm2/$PROJECT_NAME-error.log',
    out_file: '/var/log/pm2/$PROJECT_NAME-out.log',
    log_file: '/var/log/pm2/$PROJECT_NAME.log'
  }]
};
EOF

# Create log directory
mkdir -p /var/log/pm2

# Start application with PM2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup

print_status "PM2 configured and application started"

# Step 8: Nginx Configuration
echo -e "${BLUE}🌐 Configuring Nginx...${NC}"

# Backup existing nginx config if it exists
if [ -f "/etc/nginx/sites-available/$DOMAIN" ]; then
    cp /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-available/$DOMAIN.backup.$(date +%Y%m%d_%H%M%S)
fi

# Create nginx configuration
cat > /etc/nginx/sites-available/$DOMAIN << EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;

    # Main application
    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }

    # WebSocket support
    location /ws {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        proxy_pass http://localhost:$APP_PORT;
        proxy_cache_valid 200 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

# Enable site
ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test nginx configuration
nginx -t
if [ $? -eq 0 ]; then
    systemctl reload nginx
    systemctl enable nginx
    print_status "Nginx configured and reloaded"
else
    print_error "Nginx configuration test failed"
    exit 1
fi

# Step 9: Final Verification
echo -e "${BLUE}🔍 Running final verification...${NC}"

# Check if application is running
sleep 5
if pm2 show $PROJECT_NAME | grep -q "online"; then
    print_status "Application is running via PM2"
else
    print_error "Application failed to start"
    pm2 logs $PROJECT_NAME --lines 20
    exit 1
fi

# Check if application responds
if curl -f http://localhost:$APP_PORT > /dev/null 2>&1; then
    print_status "Application responding on port $APP_PORT"
else
    print_error "Application not responding"
    exit 1
fi

# Step 10: Setup SSL (optional)
echo -e "${BLUE}🔒 SSL Certificate Setup${NC}"
print_warning "For SSL, run: certbot --nginx -d $DOMAIN -d www.$DOMAIN"

# Summary
echo ""
echo -e "${GREEN}🎉 Installation Complete!${NC}"
echo "================================"
echo "✓ Application: http://$DOMAIN"
echo "✓ Database: PostgreSQL (crypto_airdrop)"
echo "✓ Process Manager: PM2"
echo "✓ Web Server: Nginx"
echo ""
echo "Management Commands:"
echo "• View logs: pm2 logs $PROJECT_NAME"
echo "• Restart app: pm2 restart $PROJECT_NAME"
echo "• Check status: pm2 status"
echo "• Nginx reload: systemctl reload nginx"
echo ""
echo "Admin credentials:"
echo "• Username: admin"
echo "• Password: admin123"
echo ""
echo -e "${YELLOW}Remember to:${NC}"
echo "1. Change default admin password"
echo "2. Set up SSL certificate with certbot"
echo "3. Configure firewall rules"
echo "4. Set up automated backups"