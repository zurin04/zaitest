# Super Simple VPS Setup Guide

## What You Need
- A VPS server (Ubuntu/Debian)
- Root access to your server
- Your project files

## Step 1: Connect to Your Server
```bash
ssh root@your-server-ip
```

## Step 2: Install Everything You Need
Copy and paste each command one by one:

```bash
# Update your server
apt update && apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PostgreSQL database
apt install -y postgresql postgresql-contrib

# Install Nginx web server
apt install -y nginx

# Install PM2 to run your app
npm install -g pm2
```

## Step 3: Upload Your Project Files
Put your project files in `/var/www/crypto-airdrop/`

```bash
# Create the folder
mkdir -p /var/www/crypto-airdrop

# Copy your files here (you can use FTP, SCP, or Git)
# Example with Git:
# git clone your-repo-url /var/www/crypto-airdrop
```

## Step 4: Set Up the Database

```bash
# Start PostgreSQL
systemctl start postgresql
systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE DATABASE crypto_airdrop;"
sudo -u postgres psql -c "CREATE USER crypto_user WITH PASSWORD 'your_password_123';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE crypto_airdrop TO crypto_user;"
```

## Step 5: Create Environment File

```bash
cd /var/www/crypto-airdrop

# Create .env file with your settings
cat > .env << 'EOF'
DATABASE_URL=postgresql://crypto_user:your_password_123@localhost:5432/crypto_airdrop
NODE_ENV=production
PORT=5000
SESSION_SECRET=change-this-to-random-text
EOF
```

## Step 6: Install App Dependencies

```bash
cd /var/www/crypto-airdrop
npm install
```

## Step 7: Set Up Database Tables
Create this script to set up your database:

```bash
cat > setup-database.sh << 'EOF'
#!/bin/bash
export $(cat .env | xargs)
PGPASSWORD=your_password_123 psql -h localhost -U crypto_user -d crypto_airdrop << 'SQL'

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password TEXT,
    wallet_address TEXT UNIQUE,
    is_admin BOOLEAN DEFAULT false,
    is_creator BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS airdrops (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    link TEXT,
    status TEXT DEFAULT 'active',
    views INTEGER DEFAULT 0,
    category_id INTEGER REFERENCES categories(id),
    posted_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS site_settings (
    id SERIAL PRIMARY KEY,
    site_name TEXT DEFAULT 'Crypto Airdrop Hub',
    site_description TEXT DEFAULT 'Discover crypto airdrops',
    created_at TIMESTAMP DEFAULT now()
);

-- Add sample data
INSERT INTO users (username, password, is_admin) VALUES 
('admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewBkuEdPzfqGULUi', true);

INSERT INTO categories (name, description) VALUES 
('DeFi', 'Decentralized Finance'),
('Gaming', 'Blockchain Games'),
('Exchange', 'Crypto Exchanges');

INSERT INTO site_settings (id) VALUES (1);

SQL
EOF

chmod +x setup-database.sh
./setup-database.sh
```

## Step 8: Configure Nginx

```bash
# Create Nginx config
cat > /etc/nginx/sites-available/crypto-airdrop << 'EOF'
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    location /ws {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
EOF

# Enable the site
ln -s /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test and restart Nginx
nginx -t
systemctl restart nginx
```

## Step 9: Start Your App

```bash
cd /var/www/crypto-airdrop

# Start with PM2
pm2 start npm --name "crypto-airdrop" -- start
pm2 save
pm2 startup
```

## Step 10: Check Everything Works

```bash
# Check if app is running
pm2 status

# Check if Nginx is running
systemctl status nginx

# Test your website
curl http://localhost:5000
```

## Done! 🎉

Your crypto airdrop platform is now running at:
- `http://your-server-ip`
- `http://your-domain.com` (if you set up a domain)

**Login with:**
- Username: `admin`
- Password: `admin123`

## If Something Goes Wrong

**App not starting?**
```bash
pm2 logs crypto-airdrop
```

**Database problems?**
```bash
systemctl status postgresql
```

**Nginx problems?**
```bash
systemctl status nginx
nginx -t
```

**Can't connect to database?**
```bash
PGPASSWORD=your_password_123 psql -h localhost -U crypto_user -d crypto_airdrop -c "SELECT 1;"
```

That's it! Your crypto airdrop platform should now be running perfectly.